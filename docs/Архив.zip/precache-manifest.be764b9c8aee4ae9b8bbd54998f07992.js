self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "56d819552f1ada88e20c53625752756f",
    "url": "/product/tender-guarantees/index.html"
  },
  {
    "revision": "9ee580482a19fe0f70d6",
    "url": "/product/tender-guarantees/static/css/main.aa1da0c2.chunk.css"
  },
  {
    "revision": "f565b1a996932c51ccb2",
    "url": "/product/tender-guarantees/static/js/2.bf9f220f.chunk.js"
  },
  {
    "revision": "ba3b4500f00880cf9656c39900077397",
    "url": "/product/tender-guarantees/static/js/2.bf9f220f.chunk.js.LICENSE"
  },
  {
    "revision": "9ee580482a19fe0f70d6",
    "url": "/product/tender-guarantees/static/js/main.35877741.chunk.js"
  },
  {
    "revision": "b7d262fd25281a8eecec",
    "url": "/product/tender-guarantees/static/js/runtime-main.eaac09d4.js"
  }
]);